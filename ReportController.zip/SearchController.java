import com.mockcompany.webapp.repository.ProductItemRepository; // Adjust package name if needed
import com.mockcompany.webapp.model.ProductItem; // Adjust package name if needed
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@RestController
public class SearchController {

    private final ProductItemRepository productItemRepository;

    @Autowired
    public SearchController(ProductItemRepository productItemRepository) {
        this.productItemRepository = productItemRepository;
    }

    /**
     * Handles HTTP GET requests to /api/products/search. Filters the products based on the query string.
     * @param query - The search query provided as a request parameter.
     * @return A collection of filtered ProductItem objects.
     */
    @GetMapping("/api/products/search")
    public Collection<ProductItem> search(@RequestParam("query") String query) {
        // Fetch all items from the database
        Iterable<ProductItem> allItems = this.productItemRepository.findAll();
        List<ProductItem> filteredItems = new ArrayList<>();
        String lowerCaseQuery = query.toLowerCase();

        // Filter items based on the query
        for (ProductItem item : allItems) {
            boolean matchesSearch = item.getName().toLowerCase().contains(lowerCaseQuery) ||
                                    item.getCategory().toLowerCase().contains(lowerCaseQuery);

            if (matchesSearch) {
                filteredItems.add(item);
            }
        }

        return filteredItems;
    }
}
